#!/home/wizard/anaconda3/bin/python

if __name__ == '__main__':

    arr = [1,5,7,90,3,71,12]

    z = int(input('enter number to search: '))

    arr.sort()
    print(f'sorted array: ', arr)

    i = 0
    j = len(arr) - 1

    while i <= j:
        if (arr[i] + arr[j] == z):
            print(f'Numbers found: {arr[i]}, and {arr[j]}')
            break
        elif (arr[i] + arr[j] < z):
            i += 1
        elif (arr[i] + arr[j] > z):
            j -=1
    else:
        print('Sorry!')
