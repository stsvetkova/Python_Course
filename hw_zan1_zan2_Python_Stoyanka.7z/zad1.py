#!/home/wizard/anaconda3/bin/python

if __name__ == '__main__':

    operation = ['+', '-', '/', '*', '//', 'q']

    while True:
        a = int(input("a = "))
        b = int(input("b = "))

        op = input('Command [+,-,/,//,*,q]: ')

        if op == 'q':
            print('Exit the Calculator')
            break
        elif op in operation:
            if   op == '+': print(f'a+b=', a+b)
            elif op == '-': print(f'a-b=', a-b)
            elif op == '/': print(f'a/b=', a/b)
            elif op == '//': print(f'a//b=', a//b)
            else: print(f'a*b=', a*b)
        else:
            print(f'Invalid Operation:{op}')